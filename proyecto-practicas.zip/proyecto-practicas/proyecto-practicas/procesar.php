<?php

$conexion = mysqli_connect("localhost","root","","restaurante_db");

if(!$conexion){
    die("Error de conexión: ".mysqli_connect_error());
}

$nombre   = $_POST['nombre'];
$apellido = $_POST['apellido'];
$telefono = $_POST['telefono'];
$email    = $_POST['email'];
$fecha    = $_POST['fecha'];
$hora     = $_POST['hora'];
$mesa     = $_POST['mesa'];

$sql = "INSERT INTO reservas 
(nombre, apellido, telefono, email, fecha_reserva, hora_reserva, mesa)
VALUES
('$nombre','$apellido','$telefono','$email','$fecha','$hora','$mesa')";

if(mysqli_query($conexion,$sql)){
    header("Location: confirmacion.php");
    exit;
}else{
    echo "Error al guardar la reserva: ".mysqli_error($conexion);
    exit;
}

mysqli_close($conexion);
?>