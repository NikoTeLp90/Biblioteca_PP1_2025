## curso
proyecto realizado por matias andino para la materia Practicas Profesionalizantes 
desarrollo de software primer año

## intro
este proyecto esta echo con PHP, HTML y CSS 
permite poder reservar una mesa en uno de los mejores restaurantes de argentina :
restaurante el pela
podras disfrutar de su menu eligiendo la mesa que mas gustes en su horarios nocturnos
(la imagenes tanto del local como la de las mesas estan echas con ia)
(cualquier parecido con la realidad es pura coincidencia)

## cuenta con
Página de bienvenida
Formulario de reserva
Confirmación de reserva
Guardado de datos en base de datos MySQL

## base de datos
la base de datos esta exportada en el archivo database/restaurante_db.sql

esta se tiene que importar en phpmyadmin para poder ser cargada
una vez cargada la base de datos podra ver las filas donde se almacena la info.

## ingresar a la pagina
Copiar el proyecto en la carpeta htdocs
Importar la base de datos 
y Abrir en el navegador la siguiente url:
http://localhost/proyecto-practicas/index.php

:b