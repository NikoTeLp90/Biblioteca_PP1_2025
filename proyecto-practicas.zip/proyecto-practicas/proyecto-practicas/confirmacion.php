<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reserva confirmada</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="fondo">
<div class="contenedor">

        <h1>¡Registro completado!</h1>

    <p class="texto-confirmacion">
        Tu reserva ha sido registrada exitosamente.<br>
        Gracias por elegir nuestro restaurante.
    </p>
    
    <div class="imagen-local">
    <img src="src/imagenes/imagendecomida.png" alt="Frente del restaurante">
    </div>

    <a href="index.php" class="btn">
        Volver al inicio
    </a>

</div>
</div>

</body>
</html>