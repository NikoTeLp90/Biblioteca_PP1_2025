<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Restaurante El Pela</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="contenedor">

    <h1>Restaurante El Pela</h1>

    <div class="descuento">
        15% de descuento en parrillada de lunes a jueves
    </div>

    <div class="menu">
        <div>
            <h2>Comidas:</h2>
            <ul>
                <li>Picadas</li>
                <li>Parrilla</li>
                <li>Guarniciones</li>
                <li>Menú Vegano</li>
                <li>Postres</li>
            </ul>
        </div>

        <div>
            <h2>Bebidas:</h2>
            <ul>
                <li>Gaseosas</li>
                <li>Vinos</li>
            </ul>
        </div>
    </div>

    <div class="bodegas">
        <h2>Nuestras Bodegas:</h2>
        <p>Trapiche · Chakaná Wines · Zuccardi · Portillo</p>
    </div>

    <div class="direccion">
        Dirección: Calle Falsa N° 123
    </div>

    <div class="imagen-local">
        <img src="src/imagenes/imagendelfrente.png" alt="Frente del restaurante">
    </div>

    <a href="formulario.php" class="boton">Reserve Mesa</a>

</div>

</body>
</html>