<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reserva de Mesa</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="contenedor">

    <h1>Reserva tu Mesa</h1>

    <form action="procesar.php" method="POST" class="formulario">

        <label>Nombre *</label>
        <input type="text" name="nombre" required>

        <label>Apellido *</label>
        <input type="text" name="apellido" required>

        <label>Teléfono / WhatsApp</label>
        <input type="text" name="telefono">

        <label>Email</label>
        <input type="email" name="email">

        <label>Día de Reserva *</label>
        <input type="date" name="fecha" required>

        <label>Horario *</label>
        <select name="hora" required>
        <option value="">Seleccionar horario</option>
        <option value="19:30">19:30</option>
        <option value="20:00">20:00</option>
        <option value="20:30">20:30</option>
        <option value="21:00">21:00</option>
        <option value="21:30">21:30</option>
        <option value="22:00">22:00</option>
        <option value="22:30">22:30</option>
        <option value="23:00">23:00</option>
        </select>

        <label>Número de Mesa *</label>
        <select name="mesa" required>
        <option value="">Seleccionar mesa</option>
        <option value="1">Mesa 1</option>
        <option value="2">Mesa 2</option>
        <option value="3">Mesa 3</option>
        <option value="4">Mesa 4</option>
        <option value="5">Mesa 5</option>
        <option value="6">Mesa 6</option>
        <option value="7">Mesa 7</option>
        <option value="8">Mesa 8</option>
        <option value="9">Mesa 9</option>
        <option value="10">Mesa 10</option>
        <option value="11">Mesa 11</option>
        <option value="12">Mesa 12</option>
        </select>

        <h3 class="titulo-mesas">Mesas a elegir:</h3>
        <img src="src/imagenes
        /imagendeelecciondemesas.png" al
        ="Plano de mesas" class="img-mesas">

        <button type="submit" class="boton">
            Confirmar Reserva
        </button>

    </form>

</div>

</body>
</html>